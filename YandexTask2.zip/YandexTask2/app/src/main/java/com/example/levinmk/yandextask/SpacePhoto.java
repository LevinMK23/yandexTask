package com.example.levinmk.yandextask;

import android.os.Parcel;
import android.os.Parcelable;

public class SpacePhoto implements Parcelable{

    String dataSource = "https://savepice.ru";
    private String url;
    private String title;

    protected SpacePhoto(String url, String title) {
        this.url = url;
        this.title = title;
    }

    protected SpacePhoto(Parcel in) {
        url = in.readString();
        title = in.readString();
    }

    public static final Creator<SpacePhoto> CREATOR = new Creator<SpacePhoto>() {
        @Override
        public SpacePhoto createFromParcel(Parcel in) {
            return new SpacePhoto(in);
        }

        @Override
        public SpacePhoto[] newArray(int size) {
            return new SpacePhoto[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(url);
        dest.writeString(title);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public static  SpacePhoto[] getSpacePhotos() {
        return new SpacePhoto[]{
                new SpacePhoto("http://i.imgur.com/zuG2bGQ.jpg", "Galaxy"),
                new SpacePhoto("http://i.imgur.com/ovr0NAF.jpg", "Space Shuttle"),
                new SpacePhoto("http://i.imgur.com/n6RfJX2.jpg", "Galaxy Orion"),
                new SpacePhoto("http://i.imgur.com/qpr5LR2.jpg", "Earth"),
                new SpacePhoto("http://i.imgur.com/pSHXfu5.jpg", "Astronaut"),
                new SpacePhoto("http://i.imgur.com/3wQcZeY.jpg", "Satellite"),
                new SpacePhoto("https://cdn1.savepice.ru/uploads/2018/4/14/4491601357446d7dece888b93db74051-full.jpg", "space1"),
                new SpacePhoto("https://cdn1.savepice.ru/uploads/2018/4/14/f42d708ae9442feb2c698e399044f806-full.jpg", "space2"),
                new SpacePhoto("https://cdn1.savepice.ru/uploads/2018/4/14/e2610e9f8b27368c139a502d57c462c1-full.jpg", "space3"),
                new SpacePhoto("https://cdn1.savepice.ru/uploads/2018/4/14/99855accec35732b108732f93fef4433-full.jpg", "space4")
        };
    }

}
