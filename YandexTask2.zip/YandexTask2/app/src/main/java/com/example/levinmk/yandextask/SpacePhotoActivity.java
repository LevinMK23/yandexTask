package com.example.levinmk.yandextask;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

public class SpacePhotoActivity extends AppCompatActivity{

    public static final String EXTRA_SPACE_PHOTO = "SpacePhotoActivity.SPACE_PHOTO";
    protected SpacePhoto spacePhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_detail);

        ImageView mImageView = findViewById(R.id.image);
        spacePhoto = getIntent().getParcelableExtra(EXTRA_SPACE_PHOTO);

        RequestOptions options = new RequestOptions()
                .centerCrop()
                .placeholder(R.drawable.load)
                .error(R.drawable.load)
                .diskCacheStrategy(DiskCacheStrategy.DATA)
                .priority(Priority.HIGH);

        Glide.with(this)
                .asBitmap()
                .load(spacePhoto.getUrl())
                .apply(options)
                .into(mImageView);
    }
}
